 <div class="bg-white mt-5 py-3">
          <div class="owl-carousel owl-theme" data-autoplay="true" data-nav="true" data-dots="false" data-loop="true" data-margin="50" data-slideby="1" data-stagepadding="25" data-items-xs="2" data-items-sm="3" data-items-md="4" data-items-lg="6">
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo1.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo2.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo3.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo8.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo6.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo11.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo7.png" alt="" /></a></div>
            <div class="item"><a href="#"><img class="img-fluid" src="images/clients/client-logo9.png" alt="" /></a></div>
          </div>
        </div>