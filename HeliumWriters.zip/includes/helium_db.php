<?php
// used to connect to the database
		/* $db_host = "localhost";
		  $db_name = "helium_db";
		 $db_username = "helium_user";
		 $db_password = "Helium@May2020";  */
		 
	 $db_name = "helium_db";
	 $db_username = "root";
	 $db_password = "HeliumWriters@May@2020";
		
		

?>