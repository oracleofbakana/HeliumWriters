<div class="row">
              <div class="col-6 col-md-4 mt-4 mt-lg-0">
                <div class="featured-box style-1 text-left">
                  <div class="featured-box-icon text-primary"><i class="far fa-smile"></i></div>
                  <h4 class="text-7 mt-n1 mb-0"><span class="counter" data-from="0" data-to="660">660</span>+</h4>
                  <p class="text-3 font-weight-300 mb-0">Happy Clients</p>
                </div>
              </div>
              <div class="col-6 col-md-4 mt-4 mt-lg-0">
                <div class="featured-box style-1 text-left">
                  <div class="featured-box-icon text-primary"><i class="far fa-check-circle"></i></div>
                  <h4 class="text-7 mt-n1 mb-0"><span class="counter" data-from="0" data-to="1500">1500</span>+</h4>
                  <p class="text-3 font-weight-300 mb-0">Done Projects</p>
                </div>
              </div>
              <div class="col-6 col-md-4 mt-4 mt-lg-0">
                <div class="featured-box style-1 text-left">
                  <div class="featured-box-icon text-primary"><i class="fas fa-award"></i></div>
                  <h4 class="text-7 mt-n1 mb-0"><span class="counter" data-from="0" data-to="72">72</span></h4>
                  <p class="text-3 font-weight-300 mb-0">Get Awards</p>
                </div>
              </div>
            </div>